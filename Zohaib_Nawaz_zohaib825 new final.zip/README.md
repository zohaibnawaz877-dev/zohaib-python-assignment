# Sunday Project – Data Quality, Insights & CSV Operations

**Student Name:** Zohaib Nawaz  
**Training ID:** zohaib825  
**Module:** AI Engineering Bootcamp – Module 02

## Files included
- `Sunday_Project.ipynb` – complete runnable notebook containing Part A and Part B.
- `sales_raw.csv` – practice input dataset containing intentional data-quality issues for cleaning.
- `cleaned_sales.csv` – cleaned Part A output with calculated revenue.
- `sales_updated.csv` – Part B output with the 5% tax calculation and Books price update.
- `revenue_by_region.png` – Part A chart showing revenue by region.
- `revenue_by_category.png` – Part A chart showing revenue by category.

## How to run
1. Extract the ZIP file.
2. Open `Sunday_Project.ipynb` in Jupyter Notebook, JupyterLab, or Google Colab.
3. Make sure all CSV files are in the same folder as the notebook.
4. Run all cells from top to bottom.
5. The notebook will recreate `cleaned_sales.csv`, `sales_updated.csv`, and both chart images.

## Dataset note
The supplied project brief names `sales_raw.csv`, but the LMS brief provided for this work did not include an original CSV dataset. Therefore, the included `sales_raw.csv` is a practice dataset created to demonstrate missing-value handling, duplicate removal, inconsistent text standardization, invalid prices, revenue calculations, summaries, and visualizations. Replace it with the instructor-provided dataset if one becomes available, then rerun the notebook.

## GitHub repository
GitHub repository URL: https://github.com/zohaibnawaz877-dev

The assignment brief asks for a GitHub repository link and meaningful Git commits. Create a repository, upload the project files, make meaningful commits, and replace the placeholder above with your actual repository URL before submission.
